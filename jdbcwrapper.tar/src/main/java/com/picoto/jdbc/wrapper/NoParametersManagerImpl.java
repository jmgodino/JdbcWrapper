package com.picoto.jdbc.wrapper;

public class NoParametersManagerImpl implements ParameterManager {

	@Override
	public void configureParameters(ParameterSetter setter) {
		return;
	}

}
